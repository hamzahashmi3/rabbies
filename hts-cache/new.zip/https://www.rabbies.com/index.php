  <!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="refresh" content="1;url=https://www.rabbies.com/en" />

        <title>Redirecting to https://www.rabbies.com/en</title>
    </head>
    <body>
        Redirecting to <a href="https://www.rabbies.com/en">https://www.rabbies.com/en</a>.
    </body>
</html>